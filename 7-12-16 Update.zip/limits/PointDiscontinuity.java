package limits;

public class PointDiscontinuity extends DiscontinuityLimitType {

}
