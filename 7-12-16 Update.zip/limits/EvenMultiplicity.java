package limits;

public class EvenMultiplicity extends VerticalDiscontinuity {

}
