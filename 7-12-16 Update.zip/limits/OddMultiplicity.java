package limits;

public class OddMultiplicity extends VerticalDiscontinuity {

}
