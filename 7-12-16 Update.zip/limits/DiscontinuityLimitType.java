package limits;

public class DiscontinuityLimitType extends LimitType {

}
