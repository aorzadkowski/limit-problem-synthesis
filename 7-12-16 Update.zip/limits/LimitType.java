package limits;

import hierarchy.LimitExpression;

public abstract class LimitType {

}
