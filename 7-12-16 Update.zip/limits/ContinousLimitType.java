package limits;

public class ContinousLimitType extends LimitType {

}
