package limits;

public class VerticalDiscontinuity {

}
