package limits;

public class JumpDiscontinuity extends DiscontinuityLimitType {

}
