package limits;

public class NegativeOddMultiplicity extends EvenMultiplicity {

}
