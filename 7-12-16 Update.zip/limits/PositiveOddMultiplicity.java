package limits;

public class PositiveOddMultiplicity extends EvenMultiplicity {

}
