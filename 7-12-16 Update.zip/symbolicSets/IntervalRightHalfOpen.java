package symbolicSets;

public class IntervalRightHalfOpen extends IntervalHalfOpen {

}
