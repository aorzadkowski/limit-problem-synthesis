package symbolicSets;

public abstract class IntervalHalfOpen extends Interval {

}
