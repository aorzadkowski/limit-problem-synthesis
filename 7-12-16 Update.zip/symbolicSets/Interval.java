package symbolicSets;

public abstract class Interval extends IntervalSet {

}
