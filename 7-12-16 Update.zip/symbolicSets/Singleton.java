package symbolicSets;

public class Singleton extends IntervalSet {

}
