package symbolicSets;

public class FuncitonMapping {

}
