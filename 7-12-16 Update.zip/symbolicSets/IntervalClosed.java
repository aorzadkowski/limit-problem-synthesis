package symbolicSets;

public class IntervalClosed extends Interval {

}
