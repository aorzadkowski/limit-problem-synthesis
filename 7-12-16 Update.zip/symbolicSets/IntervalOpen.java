package symbolicSets;

public class IntervalOpen extends Interval {

}
