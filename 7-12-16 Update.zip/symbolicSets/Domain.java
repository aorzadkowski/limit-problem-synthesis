package symbolicSets;

public class Domain {

}
