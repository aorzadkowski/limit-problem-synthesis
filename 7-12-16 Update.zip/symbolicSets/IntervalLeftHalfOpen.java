package symbolicSets;

public class IntervalLeftHalfOpen extends IntervalHalfOpen {

}
