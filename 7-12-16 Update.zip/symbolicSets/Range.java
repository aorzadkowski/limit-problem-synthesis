package symbolicSets;

public class Range {

}
