package symbolicSets;

public abstract class IntervalSet {

}
